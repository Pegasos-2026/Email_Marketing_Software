from rest_framework import viewsets,status
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser,FormParser
from django.http import HttpResponse
import csv
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models.functions import TruncHour,ExtractHour
from django.db.models import Count
from .models import Campaign
from .serializers import CampaignSerializer,CampaignListSerializer,EmailEvent
from .analytics_service import AnalyticsService
from .contact_service import ContactImportService,ContactBulkService
class CampaignViewSet(viewsets.ModelViewSet):
    permission_classes=[IsAuthenticated]
    def get_queryset(self):
        return Campaign.objects.filter(user=self.request.user).order_by('-created_at')
    def get_serializer_class(self):
        if self.action == 'list':
            return CampaignListSerializer
        return CampaignSerializer
    def create(self,request,*args,**kwargs):
        serializer=self.get_serializer(data=request.data,context={'request':request})
        serializer.is_valid(raise_exception=True)
        campaign=serializer.save()
        return Response({
            'message':'Campaign Created successfully',
            'data':CampaignSerializer(campaign).data 
        },status=status.HTTP_201_CREATED)
    def update(self,request,*args,**kwargs):
        instance=self.get_object()
        if instance.user != request.user:
            return Response({
                'error':'you do not have permission to edit this campaign'
            },status=status.HTTP_403_FORBIDDEN)
        if instance.status =='sent':
            return Response({
                'error':'Cannot edit a sent Campaign'
            },status=status.HTTP_400_BAD_REQUEST)
        serializer=self.get_serializer(instance,data=request.data,partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response({
            'message':'Campaign updated successfully',
            'data':serializer.data
        })
    def destroy(self, request, *args, **kwargs):
        instance=self.get_object()
        if instance.status in['sending','sent']:
            return Response({
                'error':'Cannot delete a sent or seing campaign'
            },status=status.HTTP_400_BAD_REQUEST)
        self.perform_destroy(instance)
        return Response({
            'error':'Campaign deleted successfully'
        },status=status.HTTP_204_NO_CONTENT)
    @action(detail=True,methods=['post'])
    def send(self,request,pk=None):
        campaign=self.get_object()
        if campaign.status=='sent':
            return Response({
                'error':'Campaign already sent'
            },status=status.HTTP_400_BAD_REQUEST)
        if not campaign.recipients.exists():
            return Response({
                'error':'No recipient added to campaign'
            },status=status.HTTP_400_BAD_REQUEST)
        try:
            if not hasattr(campaign,'content'):
                return Response({
                    'error':'Campaign Content not found'
                },status=status.HTTP_400_BAD_REQUEST)
            from .services import CampaignServicea
            service=CampaignService()
            result=service.send_campaign(campaign.id)
            return Response({
                'message':'Camapign sent successfully',
                'result':result
            },status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                'error':str(e)
            },status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    @action(detail=True,methods=['post'])
    def schedule(self,request,pk=None):
        campaign=self.get_object()
        scheduled_at=request.data.get('scheduled_at')
        if not scheduled_at:
            return Response({
                'error':'scheduled_at s required'
            },status=status.HTTP_400_BAD_REQUEST)
        campaign.scheduled_at=scheduled_at
        campaign.status='scheduled'
        campaign.save()
        return Response({
            'message':'Campaign Scheduled successfully',
            'data':CampaignSerializer(campaign)._data
        })
    @action(detail=False,methods=['get'])
    def stats(self,request):
        total=Campaign.objects.count()
        draft=Campaign.objects.filter(status='draft').count()
        scheduled=Campaign.objects.filter(status='scheduled').count()
        sent=Campaign.objects.filter(status='sent').count()
        return Response({
            'total':total,
            'draft':draft,
            'scheduled':scheduled,
            'sent':sent
        })
class DashboardAnalyticsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        service=AnalyticsService()
        data=service.get_dashboard_overview(request.user)
        return Response(data)
class CampaignAnalyticsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request,campaign_id):
        try:
            campaign=Campaign.objects.get(id=campaign_id,user=request.user)
            service=AnalyticsService()
            data=service.get_campaign_stats(campaign.id)
            return Response(data)
        except Campaign.DoesNotExist:
            return Response({'error':'Not found'},status=404)
class RefreshAnalyticsView(APIView):
    permission_classes=[IsAuthenticated]
    def post(self,request,campaign_id):
        try:
            campaign=Campaign.objects.get(id=campaign_id,user=request.user)
            service=AnalyticsService()
            analytics=service.update_campaign_analytics(campaign.id)
            return Response({
                'message':'Refreshed',
                'open_rate':analytics.open_rate,
                'click_rate':analytics.click_rate
            })
        except Campaign.DoesNotExist:
            return Response({'error':'Not found'},status=404)
class ContactImportView(APIView):
    """POST /api/contacts/inport/
    Upload CSV to import contacts"""
    permission_classes=[IsAuthenticated]
    parser_classes=[MultiPartParser,FormParser]
    def post(self,request):
        service=ContactImportService(request.user)
        try:
            #Validate file
            csv_file=request.FILES.get('file')
            service.validate_csv_file(csv_file)
            #Parse CSV
            rows=service.parse_csv_basic(csv_file)
            if rows:
                service.validate_csv_headers(rows[0].keys())
            list_id=request.data.get('list_id')
            result=service.import_contacts(rows,list_id)
            return Response({
                'success':True,
                'summary':result
            },status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({
                'error':f'Unexpected error:{str(e)}'
            },status=status.HTTP_500_INTERNAL_SERVER_ERROR)
class ContactExportView(APIView):
    """GET/api/contacts/export"""
    permission_classes=[IsAuthenticated]
    def get(self,request):
        service=ContactImportService(request.user)
        list_id=request.query_params.get('list_id')
        try:
            contacts=service.export_contacts(list_id)
            response=HttpResponse(content_type='text/csv')
            response['Content-Disposition']='attachment;filename="contacts.csv"'
            if contacts:
                writer=csv.DictWriter(response,fieldnames=contacts[0].keys())
                writer.writeheader()
                writer.writerows(contacts)
            return Response
        except Exception as e:
            return Response({
                'error':str(e)
            },status=status.HTTP_500_INTERNAL_SERVER_ERROR)
class ContactImportTemplateView(APIView):
    """GET /api/contacts/import-template/
    Download CSV template"""
    permission_classes=[IsAuthenticated]
    def get(self,request):
        service=ContactImportService(request.user)
        template_data=service.get_import_template()
        response=HttpResponse(content_type='text/csv')
        response['Content-Disposition']='attachment; filename="contact_template.csv"'
        writer=csv.DictWriter(response,fieldnames=template_data[0].keys())
        writer.writeheader()
        writer.writerows(template_data)
        return response
class ContactBulkActionsView(APIView):
    """POST /api/contacts/bulk-actions
    perform bulk ctions on contacts"""
    permission_classes=[IsAuthenticated]
    def post(self,request):
        service=ContactBulkService(request.user)
        action=request.data.get('action')
        contact_ids=request.data.get('contact_ids',[])
        if not action or not contact_ids:
            return Response({
                'error':'action and contact_ids are required'
            },status=status.HTTP_400_BAD_REQUEST)
        try:
            if action=='subscribe':
                count=service.bulk_subscribe(contact_ids)
                message=f'{count} contact(s) subscribed'
            elif action=='unsubscribe':
                count=service.bulk_unsubscribe(contact_ids)
                message=f'{count} contact(s) unsubscribed'
            elif action=='add_to_list':
                list_id=request.data.get('list_id')
                if not list_id:
                    return Response({
                        'error':'list_id is required for add_to_list_action'
                    },status=status.HTTP_400_BAD_REQUEST)
                count=service.bulk_add_to_list(contact_ids,list_id)
                message=f'{count} contact(s) added to list'
            elif action =='delete':
                count=service.bulk_delete(contact_ids)
                message=f'{count} contact(s) deleted'
            else:
                return Response({
                    'error':f'Unknown action:{action}'
                },status=status.HTTP_400_BAD_REQUEST)
            return Response({
                'success':True,
                'message':message,
                'count':count
            })
        except ValueError as e:
            return Response({
                'error':str(e)
            },status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                'error':f'Unexpected error:{str(e)}'
            },status=status.HTTP_500_INTERNAL_SERVER_ERROR)