from rest_framework import serializers
from .models import Campaign,CampaignContent,ContactList,Contact,CampaignAnalytics,EmailEvent,ClickTracking
class CampaignContentSerializer(serializers.ModelSerializer):
    class meta:
        model=CampaignContent
        fields=['html_content','plain_text_content']
class CampaignSerializer(serializers.ModelSerializer):
    content=CampaignContentSerializer(required=False)
    list_ids=serializers.ListField(child=serializers.IntegerField(),write_only=True,required=False)
    total_recipients=serializers.SerializerMethodField()
    user=serializers.StringRelatedField(read_only=True)
    class Meta:
        model=Campaign
        fields=['id','user','name','subject','preview_text','from_email',
                'from_name','reply_to','status','scheduled_at','sent_at','created_at','updated_at','content','list_ids','total_recipients']
    def get_total_recipients(self,obj):
        return obj.recipients.count()
    def create(self,validated_data):
        content_data=validated_data.pop('content',None)
        list_ids=validated_data.pop('list_ids',[])
        #logged-in user assign
        validated_data['user']=self.context['request'].user
        campaign=Campaign.objects.create(**validated_data)
        if content_data:
            CampaignContent.objects.create(campaign=campaign,**content_data)
        if list_ids:
            self._add_recipients(campaign,list_ids)
        return campaign
    def _add_recipients(self,campaign,list_ids):
        from .models import CampaignRecipient
        contacts=Contact.objects.filter(
            lists__id__in=list_ids,
            lists_user=campaign.user,
            is_subscribed=True
        ).distinct()
        recipients=[
            CampaignRecipient(campaign=campaign,contact=contact,status='pending')
            for contact in contacts
        ]
        CampaignRecipient.objects.bulk_create(recipients,ignore_conflicts=True)
class CampaignListSerializer(serializers.ModelSerializer):
    total_recipients=serializers.SerializerMethodField()
    class Meta:
        model=Campaign
        fields=['id','name','subject','status','scheduled_at','sent_at','created_at','total_recipeints']
    def get_total_recipients(self,obj):
        return obj.recipients.count()
class CampaignAnalyticsSerializer(serializers.ModelSerializer):
    campaign_name=serializers.CharField(source='campaign.name',read_only=True)
    campaign_subject=serializers.CharField(source='campaign.subject',read_only=True)
    class Meta:
        model=CampaignAnalytics
        fields=['campaign_name','campaign_subject','total_recipients','total_sent','total_delivered','total_failed','unique_opnes',
                'total_opened','unique_clicks','total_clicked','total_bounced','total_spam_reports','total_unsubscribes','delivery_rate',
                'open_rate','click_rate','click_to_open_rate','bounce_rate','last_updated',]
class EmailEventSerializer(serializers.ModelSerializer):
    contact_email=serializers.CharField(source='campaign_recipient.contact.email',read_only=True)
    class Meta:
        model=EmailEvent
        fields=[
            'id','contact_email','contact_name','event_type','clicked_url','device_type','ip_address','timestamp'
        ]
class ClickTrackingSerializer(serializers.ModelSerializer):
    class Meta:
        model=ClickTracking
        fields=['id','original_url','total_clicks','unique_clicks','created_at',]
