from django.urls import path,include
from rest_framework.routers import DefaultRouter
from .views import (CampaignViewSet,DashboardAnalyticsView,CampaignAnalyticsView,RefreshAnalyticsView)
from campaigns.view.tracking_views import track_open,track_click
router=DefaultRouter()
router.register(r'campaigns',CampaignViewSet,basename='campaign')
urlpatterns=[
    path('',include(router.urls)),
    #tracking endpoints(public-no auth required)
    path('analytics/dashboard/',DashboardAnalyticsView.as_view()),
    path('analytics/campaign/<int:campaign_id>/',CampaignAnalyticsView.as_view()),
    path('analytics/campaign/<int:campaign_id>/refresh/',RefreshAnalyticsView.as_view()),
    path('track/open/<uuid:tracking_id>/',track_open,name='track_open'),
    path('track/click/<str:short_code>/<int:recipient_id>/',track_click,name='track_click'),
]